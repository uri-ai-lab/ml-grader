''' This program test the accuracy of a ridge regression model from the testing examples in
    the directory "Sample Train Data" '''

from featureExtraction import *
import ridgeModel
import pickle
filename = 'finalized_model.sav'

def read_questions():

    train_dir = 'Sample Train Data'    
    questions_file = train_dir + '/questions'

    questions = {}
    f = open(questions_file, 'rb')
    for line in f:
    	questions = line.strip()
    f.close()

    return questions


def read_reference_answers():

    train_dir = 'Sample Train Data'    
    ref_answers_file = train_dir + '/reference answers'

    ref_answers = {}
    f = open(ref_answers_file, 'rb')
    for line in f:
    	ref_answers = line.strip()
    f.close()

    return ref_answers


def read_student_responses():

    train_dir = 'Sample Train Data'    
    student_responses_file = \
                    train_dir + '/val_responses.txt'
   
    student_responses = []
    f = open(student_responses_file, 'rb')
    for line in f:
        student_responses.append(line.strip())
    f.close()
        
    return student_responses


def read_scores():

    train_dir = 'Sample Train Data'    
    scores_file = train_dir + '/val_finalscore.txt'
    
    scores = []
    f = open(scores_file, 'rb')
    for line in f:
        line = line.strip()
        score = float(line)
        scores.append(score)
    f.close()
        
    return scores

def read_test_data():
    
    test_data = {}    
    
    questions = read_questions()
    ref_answers = read_reference_answers()
   
    student_responses = read_student_responses()
    scores = read_scores()
        
    test_data = (questions, ref_answers, student_responses, scores)

    return test_data

def extract_features(question, ref_answer, student_response):
    sim_alignment, cov_alignment, parse_results = \
                            sts_alignment(ref_answer, student_response)
    
    q_demoted_sim_alignment, q_demoted_cov_alignment, _ = \
                            sts_alignment(ref_answer, student_response,
                                          parse_results,
                                          question)

    sim_cvm = sts_cvm(ref_answer, student_response, parse_results)
    
    q_demoted_sim_cvm = sts_cvm(ref_answer, student_response,
                                parse_results,
                                question)
    
    lr = length_ratio(ref_answer, student_response, parse_results)    


    feature_vector = (sim_alignment, cov_alignment,
                      q_demoted_sim_alignment, q_demoted_cov_alignment,
                      sim_cvm,
                      q_demoted_sim_cvm,
                      lr)
    
    return feature_vector

def myround(x, base=10):
    return int(base * round(float(x)/base))

def construct_test_examples(test_data,grader):

    test_examples = []
        
    test_data = read_test_data()
    
    correct_count = 0
    n = 0
    accuracy = 0
    question = test_data[0]
    ref_answer = test_data[1]
    student_answers = test_data[2]
    scores = test_data[3]
    for i in xrange(len(student_answers)):
        features = extract_features(question, ref_answer,
                                        student_answers[i])
        score = myround(scores[i],)
        pred_score = ridgeModel.predict(grader, [features])[0]
        rscore = myround(pred_score,)
        test_examples.append((features, score,rscore))
        if rscore == score:
            correct_count += 1
        n += 1
        accuracy = float(correct_count)/n
        print "---------------------------------"
        print "Correct count: " + str(correct_count)
        print "Original Score: " + str(score)
        print "Predicted Score: " + str(rscore)
        print "Accuracy: " + str(accuracy)
        print "Response: " + str(n)

    #with open('final_results.txt', 'w') as f:
        #for item in test_examples:
            #f.write("%s\n" % item)

    return accuracy

print 'reading test data from files...'
test_data = read_test_data()
print 'done.'
print

print 'extracting features and constructing testing examples...'
accuracy = construct_test_examples(test_data,pickle.load(open(filename, 'rb')))
print 'done.'
print

print 'training the grading model...'
#accuracy = test_grader(test_examples, pickle.load(open(filename, 'rb')))
print 'done.'
print

print "Accuracy: " + str(accuracy) + "%"

