''' This program trains a ridge regression model from the training examples in
    the directory "Sample Train Data" '''

from featureExtraction import *
import ridgeModel
import trainAndApplyGrader2
import pickle

def grader(question, ref_answer, student_response, grader):
              
    features = extract_features(question, ref_answer, student_response)
    
    score = ridgeModel.predict(grader, [features])[0]
    
    return score

filename = 'finalized_model.sav'
question = "Do you think organic farming is better than conventional farming methods? Why?"
ref_answer = "Based on the information in the video, I would encourage my friends to eat more non-organic food, because while organic foods are theoretically better for the environment and our bodies, it still has negative environmental affects, such as its need for more land, which can lead to deforestation. Also, organic foods can still contain pesticides, which pretty much defeat the purpose of being organic. "
student_response = "I like the idea of organic farms because they produce a lot of jobs due to weeding and appear to be great for the environment."
#model = pickle.load(open(filename, 'rb'))
#score = grader(question, ref_answer, student_response, model)
print features
